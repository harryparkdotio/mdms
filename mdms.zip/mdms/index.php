<?php

/**
 *
 * @author Harry Park <harry@harrypark.io>
 * @link http://harrypark.io
 * @license http://opensource.org/licenses/MIT
 * @version 1.0.1
 * @package mdms - markdown management system
 *
 */

require_once('mdms.php');

$mdms = new mdms();