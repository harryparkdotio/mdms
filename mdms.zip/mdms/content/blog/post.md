---
title: First Blog Post
description: the first blog post about mdms
author: Harry Park
date: 9 July 2016
---
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ad eas enim res ab Epicuro praecepta dantur. Ergo id est convenienter naturae vivere, a natura discedere. Quare ad ea primum, si videtur; Mihi, inquam, qui te id ipsum rogavi? Duo Reges: constructio interrete. Ergo adhuc, quantum equidem intellego, causa non videtur fuisse mutandi nominis. Satis est ad hoc responsum. Falli igitur possumus.

Itaque ab his ordiamur. Suam denique cuique naturam esse ad vivendum ducem. Modo etiam paulum ad dexteram de via declinavi, ut ad Pericli sepulcrum accederem. Quantum Aristoxeni ingenium consumptum videmus in musicis? Philosophi autem in suis lectulis plerumque moriuntur. Illa argumenta propria videamus, cur omnia sint paria peccata.

At iam decimum annum in spelunca iacet. Qua ex cognitione facilior facta est investigatio rerum occultissimarum. Quid dubitas igitur mutare principia naturae? Unum nescio, quo modo possit, si luxuriosus sit, finitas cupiditates habere. Num igitur eum postea censes anxio animo aut sollicito fuisse? Quoniam, si dis placet, ab Epicuro loqui discimus. Est autem etiam actio quaedam corporis, quae motus et status naturae congruentis tenet;

Quid est, quod ab ea absolvi et perfici debeat? Si stante, hoc natura videlicet vult, salvam esse se, quod concedimus; Quod idem cum vestri faciant, non satis magnam tribuunt inventoribus gratiam. Te ipsum, dignissimum maioribus tuis, voluptasne induxit, ut adolescentulus eriperes P. A primo, ut opinor, animantium ortu petitur origo summi boni. Itaque nostrum est-quod nostrum dico, artis est-ad ea principia, quae accepimus. Quamquam tu hanc copiosiorem etiam soles dicere. Nullus est igitur cuiusquam dies natalis. A mene tu?

Ergo id est convenienter naturae vivere, a natura discedere. Quamquam in hac divisione rem ipsam prorsus probo, elegantiam desidero. An me, inquam, nisi te audire vellem, censes haec dicturum fuisse? Quid de Platone aut de Democrito loquar? Comprehensum, quod cognitum non habet? Sed quia studebat laudi et dignitati, multum in virtute processerat. Tubulum fuisse, qua illum, cuius is condemnatus est rogatione, P. Tu enim ista lenius, hic Stoicorum more nos vexat. Idem iste, inquam, de voluptate quid sentit? Estne, quaeso, inquam, sitienti in bibendo voluptas?