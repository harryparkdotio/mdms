---
title: Admin
description: Admin plugin for mdms 
author: Harry Park
status: published
template: index
---
The Admin plugin for mdms was written from the beginning alongside mdms, written to work seamlessly with each other for the best user experience. The admin plugin is technically the first plugin availible for mdms.

With the ability to create, edit, and delete content all while inside of your web browser, the admin plugin is one of the most useful availible.