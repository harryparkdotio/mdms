<?php

return [
	'admin' => ['id' => 0, 'password' => '$2y$10$QTaSuglAhfRZnf3gCwpD3OVloT1wesbWXgeZYh8YYPas7LirhPTO2', 'access_level' => 10],
	'test' => ['id' => 1, 'password' => '$2y$10$COPJqKoUHDDzojrEgLYzT.WdL52gJEc3QPV27FYc.keJKoiz9fxZG', 'access_level' => 1],
	//'jye' => ['id' => 2, 'password' => '$2y$10$IVJko/K9NWbynR/UzoM0c.hGFobf2joCX6BCZrPFubL/CGayi4c0K', 'access_level' => 10],
];