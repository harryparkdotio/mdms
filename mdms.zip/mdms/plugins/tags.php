<?php

/**
 * @package mdms - markdown management system
 * @subpackage tags - a plugin for mdms
 * @author Harry Park <harry@harrypark.io>
 * @link http://harrypark.io
 * @license http://opensource.org/licenses/MIT
 * @version 0.1
 */

require_once('Plugins.php');

class tags extends Plugins
{
	public $enabled = true;

}